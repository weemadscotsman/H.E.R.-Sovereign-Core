
import React, { useState, useCallback, useEffect } from 'react';
import { HER_Output_Structure, AlertType } from './types';
import { INITIAL_HER_DATA } from './constants';
import HerDisplayPanel from './components/HerDisplayPanel';
import EvolutionControlPanel from './components/EvolutionControlPanel';
import GitHubPanel from './components/GitHubPanel';
import SettingsPanel from './components/SettingsPanel';
import SensoryTriggerPanel from './components/SensoryTriggerPanel';
import MatrixRain from './components/MatrixRain';
import Alert from './components/shared/Alert';
import { getNextEvolution } from './services/geminiService';
import { Download, Monitor, HardDrive, Info, BookOpen } from 'lucide-react';
import { VisualTelemetryLayer } from './components/VisualTelemetryLayer';
import { vtl } from './services/telemetry';
import OperationsManual from './components/OperationsManual';

const App: React.FC = () => {
  const [herData, setHerData] = useState<HER_Output_Structure | null>(() => {
    const savedData = localStorage.getItem('herData');
    if (savedData) {
      try {
        return JSON.parse(savedData);
      } catch (e) {
        return INITIAL_HER_DATA;
      }
    }
    return INITIAL_HER_DATA;
  });
  
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [appMessage, setAppMessage] = useState<{ text: string; type: AlertType } | null>(null);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showManual, setShowManual] = useState(false);
  const [isKillSwitchActive, setIsKillSwitchActive] = useState<boolean>(() => {
    return localStorage.getItem('kill_switch_active') === 'true';
  });

  useEffect(() => {
    vtl.emit('SYS', 'HANDSHAKE', { 
      version: herData?.newVersion,
      viewport: `${window.innerWidth}x${window.innerHeight}`,
      orientation: window.screen.orientation?.type || 'unknown'
    });

    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      vtl.emit('SYS', 'INSTALL_PROMPT_READY');
    };

    const orientationHandler = () => {
      vtl.emit('SYS', 'VIEWPORT_RESIZE', { 
        w: window.innerWidth, 
        h: window.innerHeight, 
        orientation: window.screen.orientation?.type 
      });
    };

    window.addEventListener('beforeinstallprompt', handler);
    window.addEventListener('resize', orientationHandler);
    
    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
      window.removeEventListener('resize', orientationHandler);
    };
  }, []);

  useEffect(() => {
    localStorage.setItem('kill_switch_active', isKillSwitchActive.toString());
    vtl.emit('GATE', isKillSwitchActive ? 'CORE_FROZEN' : 'CORE_ARMED', {}, isKillSwitchActive ? 'BLOCKED' : 'SUCCESS');
  }, [isKillSwitchActive]);

  const handleNewEvolution = useCallback((newData: HER_Output_Structure) => {
    setHerData(newData);
    vtl.emit('EVOLUTION', 'CYCLE_COMPLETE', { version: newData.newVersion });
    setAppMessage({ text: `NODE EVOLVED: V${newData.newVersion}`, type: AlertType.SUCCESS });
  }, []);

  const clearMessage = useCallback(() => setAppMessage(null), []);
  const displayMessage = useCallback((text: string, type: AlertType) => {
    setAppMessage({ text, type });
    vtl.emit('SYS', 'ALERT_EMITTED', { text, type });
  }, []);

  const triggerManualMutation = useCallback(async () => {
    if (isKillSwitchActive) {
      vtl.emit('EVOLUTION', 'MUTATION_BLOCKED', { reason: 'KILL_SWITCH' }, 'BLOCKED');
      return;
    }
    if (!herData || isLoading) return;
    
    setIsLoading(true);
    vtl.emit('EVOLUTION', 'MUTATION_START', { current: herData.newVersion });
    
    try {
      const evolved = await getNextEvolution(
        herData.newFullPrompt,
        herData.nextPlannedMutationText,
        herData.newVersion,
        herData.causalHistory
      );
      handleNewEvolution(evolved);
    } catch (err: any) {
      vtl.emit('EVOLUTION', 'MUTATION_FAILED', { error: err.message }, 'ERROR');
      displayMessage(err.message, AlertType.ERROR);
    } finally {
      setIsLoading(false);
    }
  }, [herData, isLoading, isKillSwitchActive, handleNewEvolution, displayMessage]);

  return (
    <div className="min-h-screen flex flex-col items-center p-2 md:p-4 selection:bg-primary/50 overflow-x-hidden">
      <MatrixRain active={isLoading} />
      <VisualTelemetryLayer isKillSwitchActive={isKillSwitchActive} />
      <OperationsManual isOpen={showManual} onClose={() => setShowManual(false)} />
      
      <header className="w-full max-w-7xl mb-4 md:mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative group text-center md:text-left">
          <h1 className="text-3xl md:text-5xl font-orbitron font-black text-transparent bg-clip-text bg-gradient-to-b from-primary-light via-primary to-secondary tracking-tighter uppercase italic">
            H.E.R. Sovereign Core
          </h1>
          <div className="absolute -bottom-2 left-0 w-full h-0.5 bg-primary/40 shadow-[0_0_15px_rgba(0,212,255,0.4)]"></div>
        </div>

        <div className="flex gap-2">
          <button 
            onClick={() => {
              vtl.emit('SYS', 'OPEN_MANUAL');
              setShowManual(true);
            }}
            className="px-3 py-1.5 bg-neutral-800 border border-neutral-700 rounded text-[10px] font-mono text-neutral-400 flex items-center gap-2 hover:bg-neutral-700 transition-all uppercase"
          >
            <BookOpen className="h-3 w-3" /> Ops Manual
          </button>
          {deferredPrompt && (
            <button 
              onClick={() => {
                vtl.emit('SYS', 'INSTALL_ATTEMPT');
                deferredPrompt.prompt();
              }}
              className="px-3 py-1.5 bg-primary/20 border border-primary/50 rounded text-[10px] font-mono text-primary-light flex items-center gap-2 hover:bg-primary/30 transition-all uppercase"
            >
              <Monitor className="h-3 w-3" /> Install
            </button>
          )}
        </div>
      </header>

      {appMessage && (
        <div className="w-full max-w-5xl mb-4 md:mb-6">
          <Alert type={appMessage.type} message={appMessage.text} onClose={clearMessage} />
        </div>
      )}

      <div className="w-full max-w-7xl grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8 relative pb-24 lg:pb-0">
        <div className="lg:col-span-3 flex flex-col gap-6 order-2 lg:order-1">
          <SettingsPanel displayAppMessage={displayMessage} />
          
          <SensoryTriggerPanel 
            onTrigger={triggerManualMutation} 
            displayAppMessage={displayMessage}
            disabled={isLoading || isKillSwitchActive}
            isKillSwitchActive={isKillSwitchActive}
          />

          <EvolutionControlPanel
            currentHerData={herData}
            onNewEvolution={handleNewEvolution}
            setLoading={setIsLoading}
            displayAppMessage={displayMessage}
            isLoading={isLoading}
            disabled={isKillSwitchActive}
          />

          <GitHubPanel
            currentHerData={herData}
            setLoading={setIsLoading}
            displayAppMessage={displayMessage}
            isLoading={isLoading}
            isKillSwitchActive={isKillSwitchActive}
            setIsKillSwitchActive={setIsKillSwitchActive}
          />
        </div>

        <div className="lg:col-span-9 space-y-6 md:space-y-8 order-1 lg:order-2">
          <div className="bg-black/60 backdrop-blur-md border border-neutral-800 rounded-lg p-1 overflow-hidden">
            <HerDisplayPanel herData={herData} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
