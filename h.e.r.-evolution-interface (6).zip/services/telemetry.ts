
export type TelemetrySubsystem = 'SENSOR' | 'EVOLUTION' | 'GATE' | 'VERIFY' | 'PERSIST' | 'AUTH' | 'SYS';

export interface TelemetryEvent {
  timestamp: string;
  subsystem: TelemetrySubsystem;
  action: string;
  payload: any;
  status: 'SUCCESS' | 'ERROR' | 'BLOCKED' | 'PENDING';
}

type TelemetryListener = (event: TelemetryEvent) => void;

class TelemetryBus {
  private listeners: TelemetryListener[] = [];
  private history: TelemetryEvent[] = [];

  emit(subsystem: TelemetrySubsystem, action: string, payload: any = {}, status: TelemetryEvent['status'] = 'SUCCESS') {
    const event: TelemetryEvent = {
      timestamp: new Date().toISOString(),
      subsystem,
      action,
      payload,
      status
    };
    this.history.push(event);
    if (this.history.length > 100) this.history.shift();
    this.listeners.forEach(l => l(event));
    console.debug(`[VTL][${subsystem}] ${action}`, payload);
  }

  subscribe(listener: TelemetryListener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  getHistory() {
    return [...this.history];
  }
}

export const vtl = new TelemetryBus();
