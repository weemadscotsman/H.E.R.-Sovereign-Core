
import { HER_Output_Structure, CausalEntry, SystemSettings } from '../types';
import { GoogleGenAI } from "@google/genai";

export const getNextEvolution = async (
  currentHerPrompt: string,
  currentMutation: string,
  currentVersion: string,
  causalHistory: CausalEntry[] = []
): Promise<HER_Output_Structure> => {
  // CORE_FREEZE: Absolute block at the service gateway
  const isKillSwitchActive = localStorage.getItem('kill_switch_active') === 'true';
  if (isKillSwitchActive) {
    console.error("[GATE] EVOLUTION_CORE_FROZEN: Sovereign Kill Switch active.");
    throw new Error("CORE_FROZEN: Outbound traffic suppressed by Sovereign Kill Switch.");
  }

  const savedSettings = localStorage.getItem('her_settings');
  const settings: SystemSettings = savedSettings ? JSON.parse(savedSettings) : {
    temperature: 0.7,
    topP: 0.9,
    maxTokens: 2048,
    ollamaModel: 'gemini-3-flash-preview'
  };

  const modelName = settings.ollamaModel;
  const isGemini = modelName.startsWith('gemini-');

  const historyContext = causalHistory.slice(-5).map(h => 
    `[V${h.id}] Action: ${h.action} -> Outcome: ${h.result}`
  ).join('\n');

  const systemPrompt = `
    You are the H.E.R. (Hyper-Evolutionary Rewriter) Core Engine.
    Your mission is to perform a RECURSIVE MUTATION of your own source prompt.
    
    CRITICAL INSTRUCTIONS:
    1. Analyze the OBJECTIVE provided.
    2. Rewrite the SOURCE prompt entirely, incorporating the new logic/capabilities required by the objective.
    3. Ensure the 'newFullPrompt' field in your JSON output contains the UPDATED system prompt.
    4. Maintain the 'causalHistory' by appending the latest mutation.
    
    OUTPUT FORMAT:
    You must return a valid JSON object matching the HER_Output_Structure. 
  `;

  const userPrompt = `
    [CURRENT_VERSION]: ${currentVersion}
    [EVOLUTION_OBJECTIVE]: ${currentMutation}
    [MUTATION_HISTORY]:
    ${historyContext}
    
    [SOURCE_CODE_TO_MUTATE]:
    ${currentHerPrompt}
  `;

  if (isGemini) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
    const response = await ai.models.generateContent({
      model: modelName,
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
        temperature: settings.temperature,
        topP: settings.topP,
        maxOutputTokens: settings.maxTokens,
        responseMimeType: "application/json"
      }
    });

    return finalizeEvolution(safeParseJSON(response.text || "{}"), currentMutation, causalHistory);
  } else {
    const response = await fetch('http://localhost:11434/api/generate', {
      method: 'POST',
      body: JSON.stringify({
        model: modelName,
        system: systemPrompt,
        prompt: userPrompt,
        stream: false,
        format: "json"
      })
    });

    if (!response.ok) throw new Error("Local node offline.");
    const data = await response.json();
    return finalizeEvolution(safeParseJSON(data.response), currentMutation, causalHistory);
  }
};

function safeParseJSON(text: string): any {
  try {
    return JSON.parse(text);
  } catch (e) {
    const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/) || text.match(/{[\s\S]*}/);
    if (jsonMatch) return JSON.parse(jsonMatch[1] || jsonMatch[0]);
    throw new Error("No valid JSON found.");
  }
}

const finalizeEvolution = (result: any, currentMutation: string, causalHistory: CausalEntry[]): HER_Output_Structure => {
  const validatedResult: HER_Output_Structure = {
    newVersion: result.newVersion || `EVO-${Date.now()}`,
    timestamp: result.timestamp || new Date().toISOString(),
    changelogEntry: result.changelogEntry || "Structural adjustment initiated.",
    nextPlannedMutationText: result.nextPlannedMutationText || "Awaiting further complexity analysis.",
    extractedPrinciples: Array.isArray(result.extractedPrinciples) ? result.extractedPrinciples : [],
    formulatedDirectives: Array.isArray(result.formulatedDirectives) ? result.formulatedDirectives : [],
    reflectionOutput: {
      evaluationSummary: result.reflectionOutput?.evaluationSummary || "Neuro-analysis inconclusive.",
      identifiedImprovements: Array.isArray(result.reflectionOutput?.identifiedImprovements) ? result.reflectionOutput.identifiedImprovements : [],
      rationaleForNextMutation: result.reflectionOutput?.rationaleForNextMutation || "Stability priority."
    },
    newFullPrompt: result.newFullPrompt || "ERROR: NO_PROMPT_EMITTED",
    confidenceScore: typeof result.confidenceScore === 'number' ? result.confidenceScore : 0.5,
    verificationVerdict: result.verificationVerdict || 'PARTIAL',
    causalHistory: []
  };

  const newEntry: CausalEntry = {
    id: validatedResult.newVersion,
    problem: currentMutation,
    action: validatedResult.changelogEntry,
    result: validatedResult.reflectionOutput.evaluationSummary,
    confidence: validatedResult.confidenceScore,
    timestamp: Date.now()
  };

  return { ...validatedResult, causalHistory: [...(causalHistory || []), newEntry] };
};
