
import { HER_Output_Structure, GitHubRepoConfig } from '../types';

/**
 * Real GitHub Persistence Service
 * Uses the GitHub REST API to manage the evolution ledger.
 */

export const commitAndPushToGitHub = async (
  herData: HER_Output_Structure,
  token: string
): Promise<{ success: boolean; message: string; url?: string }> => {
  const OWNER = 'me'; // In production, this is fetched via /user
  const REPO = 'her-evolution-logs';
  const FILE_PATH = `logs/V${herData.newVersion}.md`;
  
  try {
    // 1. Get current user to verify token
    const userRes = await fetch('https://api.github.com/user', {
      headers: { 'Authorization': `token ${token}` }
    });
    if (!userRes.ok) throw new Error("Unauthorized: GitHub Handshake Failed");
    const userData = await userRes.json();
    const login = userData.login;

    // 2. Prepare content
    const content = herData.newFullPrompt;
    const message = `[H.E.R. EVOLUTION] V${herData.newVersion} - ${herData.changelogEntry.substring(0, 50)}`;
    
    // 3. Create/Update file (Simplified for browser-direct flow)
    // In a full implementation, we'd handle SHA for updates, 
    // but for logs we create unique versioned files.
    const putRes = await fetch(`https://api.github.com/repos/${login}/${REPO}/contents/${FILE_PATH}`, {
      method: 'PUT',
      headers: {
        'Authorization': `token ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message,
        content: btoa(unescape(encodeURIComponent(content))), // Base64 encode UTF-8
        branch: 'main'
      })
    });

    if (putRes.status === 404) {
      throw new Error(`Repository '${REPO}' not found. Please create it on GitHub first.`);
    }

    if (!putRes.ok) {
      const error = await putRes.json();
      throw new Error(error.message || "Push failed");
    }

    return {
      success: true,
      message: `V${herData.newVersion} committed to ${login}/${REPO}`,
      url: `https://github.com/${login}/${REPO}`
    };
  } catch (error: any) {
    console.error("[GitHub Engine Error]", error);
    return {
      success: false,
      message: error.message
    };
  }
};
