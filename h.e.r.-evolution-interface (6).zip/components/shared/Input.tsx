
import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  Icon?: React.ElementType;
}

const Input: React.FC<InputProps> = ({ label, id, Icon, className = '', ...props }) => {
  return (
    <div className="w-full">
      {label && (
        <label htmlFor={id} className="block text-sm font-medium text-neutral-300 mb-1">
          {label}
        </label>
      )}
      <div className="relative rounded-md shadow-sm">
        {Icon && (
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <Icon className="h-5 w-5 text-neutral-400" aria-hidden="true" />
            </div>
        )}
        <input
          id={id}
          className={`block w-full ${Icon ? 'pl-10' : 'px-3'} py-2 bg-neutral-800 border border-neutral-700 rounded-md text-neutral-100 placeholder-neutral-500 focus:outline-none focus:ring-2 focus:ring-primary-dark focus:border-primary-dark sm:text-sm ${className}`}
          {...props}
        />
      </div>
    </div>
  );
};

export default Input;
