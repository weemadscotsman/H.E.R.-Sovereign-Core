
import React from 'react';

interface CardProps {
  title?: string;
  children: React.ReactNode;
  className?: string;
  titleClassName?: string;
  Icon?: React.ElementType;
}

const Card: React.FC<CardProps> = ({ title, children, className = '', titleClassName = '', Icon }) => {
  return (
    <div className={`bg-neutral-900/80 backdrop-blur-sm border border-neutral-800/50 shadow-[0_0_20px_rgba(0,0,0,0.5)] rounded-sm p-5 relative overflow-hidden group ${className}`}>
      {/* Corner Accents */}
      <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-primary/50"></div>
      <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-primary/50"></div>
      <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-primary/50"></div>
      <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-primary/50"></div>

      {title && (
        <div className="flex items-center mb-6 border-b border-neutral-800 pb-3">
          {Icon && <Icon className="h-4 w-4 mr-3 text-primary drop-shadow-[0_0_8px_rgba(0,212,255,0.6)]" />}
          <h2 className={`text-xs font-orbitron font-black tracking-[0.2em] uppercase text-primary-light ${titleClassName}`}>
            {title}
          </h2>
        </div>
      )}
      <div className="text-neutral-400 font-sans">{children}</div>
    </div>
  );
};

export default Card;
