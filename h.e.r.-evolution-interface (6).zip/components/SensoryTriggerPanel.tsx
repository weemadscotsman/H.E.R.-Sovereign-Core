
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AlertType } from '../types';
import Card from './shared/Card';
import { Mic, Video, Radio, Zap, Eye, EyeOff, MicOff, Lock, Unlock, ShieldOff, Activity, Clock } from 'lucide-react';
import { vtl } from '../services/telemetry';

interface SensoryTriggerPanelProps {
  onTrigger: () => void;
  displayAppMessage: (text: string, type: AlertType) => void;
  disabled: boolean;
  isKillSwitchActive: boolean;
}

const SensoryTriggerPanel: React.FC<SensoryTriggerPanelProps> = ({ onTrigger, displayAppMessage, disabled, isKillSwitchActive }) => {
  const [isWatching, setIsWatching] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isArmed, setIsArmed] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);
  const [lastTriggerTime, setLastTriggerTime] = useState(0);
  const [cooldownRemaining, setCooldownRemaining] = useState(0);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const recognitionRef = useRef<any>(null);
  const lastFrameRef = useRef<ImageData | null>(null);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const COOLDOWN_MS = 45000;

  const killHardware = useCallback(() => {
    vtl.emit('SENSOR', 'HARDWARE_RELEASE', { active_video: !!videoRef.current?.srcObject, active_recognition: !!recognitionRef.current });
    if (videoRef.current?.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
      videoRef.current.srcObject = null;
    }
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    
    setIsWatching(false);
    setIsListening(false);
    setAudioLevel(0);
    lastFrameRef.current = null;
  }, []);

  useEffect(() => {
    if (isKillSwitchActive) killHardware();
  }, [isKillSwitchActive, killHardware]);

  useEffect(() => {
    if (lastTriggerTime === 0) return;
    const interval = setInterval(() => {
      const remaining = Math.max(0, COOLDOWN_MS - (Date.now() - lastTriggerTime));
      setCooldownRemaining(remaining);
      if (remaining === 0) clearInterval(interval);
    }, 100);
    return () => clearInterval(interval);
  }, [lastTriggerTime]);

  const handleTriggerIntent = useCallback(() => {
    if (isKillSwitchActive || !isArmed || disabled) return;
    const now = Date.now();
    if (now - lastTriggerTime < COOLDOWN_MS) {
      vtl.emit('GATE', 'TRIGGER_REJECTED', { cooldown: true }, 'BLOCKED');
      return;
    }
    
    vtl.emit('SENSOR', 'INTENT_DETECTED', { timestamp: now });
    setLastTriggerTime(now);
    onTrigger();
    displayAppMessage("SENSORY_TRIGGER: Evolution cycle initiated.", AlertType.INFO);
  }, [isKillSwitchActive, isArmed, disabled, lastTriggerTime, onTrigger, displayAppMessage]);

  const toggleListening = async () => {
    if (isKillSwitchActive) return;
    if (isListening) {
      killHardware();
      return;
    }

    try {
      vtl.emit('SENSOR', 'MIC_REQUEST');
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioContextRef.current = new AudioContext();
      analyserRef.current = audioContextRef.current.createAnalyser();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      source.connect(analyserRef.current);
      
      const update = () => {
        if (!analyserRef.current || isKillSwitchActive) return;
        const data = new Uint8Array(analyserRef.current.frequencyBinCount);
        analyserRef.current.getByteFrequencyData(data);
        const level = data.reduce((a, b) => a + b) / data.length;
        setAudioLevel(level);
        animationFrameRef.current = requestAnimationFrame(update);
      };
      update();

      const Speech = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (Speech) {
        recognitionRef.current = new Speech();
        recognitionRef.current.continuous = true;
        recognitionRef.current.onresult = (e: any) => {
          const transcript = e.results[e.results.length-1][0].transcript.toLowerCase();
          vtl.emit('SENSOR', 'NLP_TRANSCRIPT', { text: transcript });
          if (transcript.includes("initiate evolution") || transcript.includes("mutate now")) {
            handleTriggerIntent();
          }
        };
        recognitionRef.current.start();
      }
      setIsListening(true);
      vtl.emit('SENSOR', 'MIC_ACTIVE');
    } catch (e) {
      vtl.emit('SENSOR', 'MIC_ERROR', { error: 'Permission denied' }, 'ERROR');
      displayAppMessage("Audio permission rejected.", AlertType.ERROR);
    }
  };

  const toggleWatching = async () => {
    if (isKillSwitchActive) return;
    if (isWatching) {
      killHardware();
      return;
    }
    try {
      vtl.emit('SENSOR', 'CAMERA_REQUEST');
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsWatching(true);
        vtl.emit('SENSOR', 'CAMERA_ACTIVE');
      }
    } catch (e) {
      vtl.emit('SENSOR', 'CAMERA_ERROR', { error: 'Permission denied' }, 'ERROR');
      displayAppMessage("Optical permission rejected.", AlertType.ERROR);
    }
  };

  useEffect(() => {
    if (!isWatching || isKillSwitchActive) return;
    const loop = () => {
      if (!videoRef.current || !canvasRef.current || isKillSwitchActive) return;
      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(videoRef.current, 0, 0, 160, 120);
      const frame = ctx.getImageData(0, 0, 160, 120);
      if (lastFrameRef.current) {
        let diff = 0;
        for (let i = 0; i < frame.data.length; i += 4) {
          if (Math.abs(frame.data[i] - lastFrameRef.current.data[i]) > 60) diff++;
        }
        if (diff > (160 * 120 * 0.25)) {
          vtl.emit('SENSOR', 'MOTION_TRIGGER', { magnitude: diff });
          handleTriggerIntent();
        }
      }
      lastFrameRef.current = frame;
      requestAnimationFrame(loop);
    };
    const id = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(id);
  }, [isWatching, isKillSwitchActive, handleTriggerIntent]);

  return (
    <Card title="Sensory Telemetry" Icon={Radio}>
      <div className="space-y-4">
        <div className="flex flex-col gap-2">
          <button 
            onClick={() => {
              vtl.emit('SENSOR', isArmed ? 'SAFETY_ENGAGED' : 'ARM_ENGAGED');
              setIsArmed(!isArmed);
            }} 
            disabled={isKillSwitchActive}
            className={`w-full py-3 rounded border flex items-center justify-center gap-2 transition-all font-orbitron text-[10px] font-black tracking-[0.2em] ${
              isArmed 
              ? 'bg-primary/20 border-primary text-primary-light shadow-[0_0_15px_rgba(0,212,255,0.2)]' 
              : 'bg-neutral-800 border-neutral-700 text-neutral-500'
            }`}
          >
            {isArmed ? <Unlock className="h-3 w-3 animate-pulse" /> : <Lock className="h-3 w-3" />}
            SYSTEM_ARM: {isArmed ? 'ACTIVE' : 'STBY'}
          </button>
          
          {cooldownRemaining > 0 && (
            <div className="flex items-center justify-center gap-2 text-[8px] font-mono text-secondary-light uppercase animate-pulse">
              <Clock className="h-3 w-3" /> Sensor Cooldown: {(cooldownRemaining / 1000).toFixed(1)}s
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button onClick={toggleListening} disabled={isKillSwitchActive} className={`flex flex-col items-center p-3 rounded border transition-all ${isListening ? 'bg-primary/20 border-primary shadow-[inset_0_0_10px_rgba(0,212,255,0.1)]' : 'bg-neutral-900 border-neutral-800'}`}>
            <Mic className={`h-4 w-4 ${isListening ? 'text-primary' : 'text-neutral-600'}`} />
            <span className="text-[7px] mt-1 uppercase font-mono tracking-tighter">Audio_Feed</span>
          </button>
          <button onClick={toggleWatching} disabled={isKillSwitchActive} className={`flex flex-col items-center p-3 rounded border transition-all ${isWatching ? 'bg-secondary/20 border-secondary shadow-[inset_0_0_10px_rgba(139,0,255,0.1)]' : 'bg-neutral-900 border-neutral-800'}`}>
            <Video className={`h-4 w-4 ${isWatching ? 'text-secondary' : 'text-neutral-600'}`} />
            <span className="text-[7px] mt-1 uppercase font-mono tracking-tighter">Optical_Feed</span>
          </button>
        </div>

        {isWatching && (
          <div className="relative aspect-video bg-black rounded overflow-hidden border border-neutral-800 shadow-inner">
            <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover grayscale brightness-50 contrast-125 mirror" />
            <div className="absolute top-2 left-2 flex gap-1">
               <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></div>
               <span className="text-[8px] font-mono text-red-500 uppercase font-black">REC</span>
            </div>
            <canvas ref={canvasRef} width="160" height="120" className="hidden" />
          </div>
        )}
        
        {isListening && (
          <div className="space-y-1">
             <div className="h-1 bg-neutral-950 rounded-full overflow-hidden border border-neutral-800">
                <div className="h-full bg-primary transition-all duration-75 shadow-[0_0_8px_#00d4ff]" style={{ width: `${Math.min(100, (audioLevel / 128) * 100)}%` }} />
             </div>
             <div className="text-[6px] font-mono text-neutral-600 uppercase text-right tracking-widest">RMS_TELEMETRY</div>
          </div>
        )}
      </div>
    </Card>
  );
};

export default SensoryTriggerPanel;
