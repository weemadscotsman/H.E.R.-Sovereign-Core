
import React, { useState, useEffect } from 'react';
import { HER_Output_Structure, AlertType } from '../types';
import Button from './shared/Button';
import Card from './shared/Card';
import { Github, LogIn, Unlink, Power, ShieldAlert, Lock, Database, RefreshCcw } from 'lucide-react';
import { commitAndPushToGitHub } from '../services/githubService';

interface GitHubPanelProps {
  currentHerData: HER_Output_Structure | null;
  setLoading: (loading: boolean) => void;
  displayAppMessage: (text: string, type: AlertType) => void;
  isLoading: boolean;
  isKillSwitchActive: boolean;
  setIsKillSwitchActive: (active: boolean) => void;
}

const GitHubPanel: React.FC<GitHubPanelProps> = ({
  currentHerData,
  setLoading,
  displayAppMessage,
  isLoading,
  isKillSwitchActive,
  setIsKillSwitchActive
}) => {
  const [token, setToken] = useState<string | null>(localStorage.getItem('gh_token'));

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const receivedToken = params.get('token'); 
    if (receivedToken) {
      // SECURITY: If kill switch is active during callback, discard token
      if (localStorage.getItem('kill_switch_active') === 'true') {
        displayAppMessage("AUTH_BLOCKED: Kill Switch suppressed incoming token.", AlertType.ERROR);
      } else {
        localStorage.setItem('gh_token', receivedToken);
        setToken(receivedToken);
        displayAppMessage("Identity Handshake Successful", AlertType.SUCCESS);
      }
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [displayAppMessage]);

  // H.E.R. Auto-Persistence Hook
  useEffect(() => {
    if (!token || !currentHerData || isKillSwitchActive) return;
    
    // Auto-persist on major version changes
    const lastPersisted = localStorage.getItem('last_persisted_version');
    if (lastPersisted !== currentHerData.newVersion) {
      handleSync();
      localStorage.setItem('last_persisted_version', currentHerData.newVersion);
    }
  }, [currentHerData, token, isKillSwitchActive]);

  const handleConnect = () => {
    if (isKillSwitchActive) return;
    const CLIENT_ID = "Iv23liO6YhL7zC8WvG9n"; 
    const REDIRECT_URI = window.location.origin;
    // Route through the secure Auth Broker
    window.location.href = `https://github.com/login/oauth/authorize?client_id=${CLIENT_ID}&scope=repo&redirect_uri=${REDIRECT_URI}`;
  };

  const handleDisconnect = () => {
    localStorage.removeItem('gh_token');
    setToken(null);
    displayAppMessage("Sovereign Isolation Restored.", AlertType.WARNING);
  };

  const toggleKillSwitch = () => {
    const newState = !isKillSwitchActive;
    setIsKillSwitchActive(newState);
    if (newState) {
      displayAppMessage("UPLINKS SEVERED // CORE_FROZEN", AlertType.ERROR);
      // Hard stop on any active hardware if somehow still lingering
      localStorage.setItem('kill_switch_active', 'true');
    } else {
      displayAppMessage("Neural Handshake Online", AlertType.SUCCESS);
      localStorage.setItem('kill_switch_active', 'false');
    }
  };

  const handleSync = async () => {
    if (isKillSwitchActive || !currentHerData || !token) return;
    setLoading(true);
    try {
      const result = await commitAndPushToGitHub(currentHerData, token);
      displayAppMessage(result.message, result.success ? AlertType.SUCCESS : AlertType.ERROR);
    } catch (e: any) {
      displayAppMessage(e.message, AlertType.ERROR);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card title="Sovereign Isolation" Icon={ShieldAlert}>
        <div className="space-y-4">
          <button 
            onClick={toggleKillSwitch}
            className={`w-full p-6 rounded border-2 transition-all flex flex-col items-center gap-3 relative group ${
              isKillSwitchActive 
              ? 'bg-red-950/40 border-red-500 shadow-[0_0_30px_rgba(239,68,68,0.4)] animate-pulse' 
              : 'bg-neutral-900 border-neutral-700 hover:border-primary/50'
            }`}
          >
            <div className={`absolute inset-0 bg-red-500/5 opacity-0 ${isKillSwitchActive ? 'opacity-100' : ''}`}></div>
            <Power className={`h-10 w-10 relative z-10 ${isKillSwitchActive ? 'text-red-500 drop-shadow-[0_0_10px_#ef4444]' : 'text-neutral-500 group-hover:text-primary transition-colors'}`} />
            <span className={`text-[10px] font-black uppercase tracking-[0.4em] relative z-10 ${isKillSwitchActive ? 'text-red-400' : 'text-neutral-400 group-hover:text-primary-light transition-colors'}`}>
              {isKillSwitchActive ? 'SYSTEM_LOCKED' : 'SYSTEM_ARMED'}
            </span>
          </button>
          <div className="text-[8px] font-mono text-neutral-600 uppercase text-center leading-relaxed">
            * SEVERS ALL HARDWARE UPLINKS<br/>
            * BLOCKS OUTBOUND API_CORE<br/>
            * SUSPENDS AUTONOMOUS EVOLUTION
          </div>
        </div>
      </Card>

      <Card title="Persistence Layer" Icon={Github}>
        {!token ? (
          <Button onClick={handleConnect} disabled={isKillSwitchActive} className="w-full font-orbitron text-[10px] tracking-widest" Icon={LogIn}>
            Broker Authentication
          </Button>
        ) : (
          <div className="space-y-3">
            <div className={`flex items-center justify-between p-3 border rounded transition-all ${isKillSwitchActive ? 'bg-neutral-900 border-neutral-800' : 'bg-primary/5 border-primary/20'}`}>
              <div className="flex items-center gap-2">
                <Database className={`h-3 w-3 ${isKillSwitchActive ? 'text-neutral-700' : 'text-primary'}`} />
                <span className={`text-[9px] font-black uppercase tracking-widest ${isKillSwitchActive ? 'text-neutral-600' : 'text-primary'}`}>Uplink: {isKillSwitchActive ? 'Severed' : 'Active'}</span>
              </div>
              <button onClick={handleDisconnect} className="text-neutral-500 hover:text-red-400 transition-colors">
                <Unlink className="h-3 w-3" />
              </button>
            </div>
            <Button onClick={handleSync} disabled={isLoading || isKillSwitchActive} variant="secondary" className="w-full group" Icon={RefreshCcw}>
              Manual Sync Pulse
            </Button>
            <div className="text-[7px] font-mono text-neutral-700 uppercase text-center italic">
              {isKillSwitchActive ? 'AUTO_PERSIST: FROZEN' : 'AUTO_PERSIST: ENABLED'}
            </div>
          </div>
        )}
      </Card>
    </div>
  );
};

export default GitHubPanel;
