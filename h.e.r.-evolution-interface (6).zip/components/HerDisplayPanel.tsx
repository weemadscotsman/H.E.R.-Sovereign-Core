
import React, { useState } from 'react';
import { HER_Output_Structure } from '../types';
import Card from './shared/Card';
import TextArea from './shared/TextArea';
import { 
  FileText, Info, Zap, GitBranch, ShieldCheck, 
  BrainCircuit, MessageSquare, Terminal, Eye, 
  Cpu, Layers, Target, Activity, Database, Sparkles, Code2, ArrowRight
} from 'lucide-react';

interface HerDisplayPanelProps {
  herData: HER_Output_Structure | null;
}

const HerDisplayPanel: React.FC<HerDisplayPanelProps> = ({ herData }) => {
  const [showDiff, setShowDiff] = useState(false);

  if (!herData) {
    return (
      <Card title="CORE_DUMP: EMPTY" Icon={Info}>
        <div className="flex flex-col items-center justify-center py-24 opacity-50 border-2 border-dashed border-neutral-800 rounded">
           <Terminal className="h-16 w-16 mb-6 animate-pulse text-primary" />
           <p className="font-orbitron text-sm uppercase tracking-[0.4em] text-primary">Awaiting Neural Link...</p>
           <p className="font-mono text-[9px] mt-2 text-neutral-600">IDLE_PROCESS_ID: {Math.random().toString(16).slice(2, 10)}</p>
        </div>
      </Card>
    );
  }

  const getVerdictColor = (v: string) => {
    if (v === 'VALID') return 'text-green-400';
    if (v === 'PARTIAL') return 'text-yellow-400';
    return 'text-red-500';
  };

  // Basic diff indicator logic for visualization
  const currentPrompt = herData.newFullPrompt;
  const previousPrompt = herData.causalHistory.length > 1 ? "RETRIEVING_PREVIOUS_VERSION..." : "GENESIS_VERSION";

  return (
    <div className="space-y-6 animate-in fade-in duration-700">
      {/* GLOBAL SYSTEM STATUS BAR */}
      <div className="flex items-center gap-2 mb-2">
        <div className="flex-1 h-[1px] bg-gradient-to-r from-primary/40 to-transparent"></div>
        <span className="font-orbitron text-[9px] font-black text-primary tracking-[0.4em] uppercase flex items-center gap-2 bg-primary/5 px-3 py-1 rounded-full border border-primary/20 shadow-[0_0_10px_rgba(0,212,255,0.1)]">
          <Activity className="h-3 w-3 animate-pulse" /> Live Telemetry Feed // SOVEREIGN_V{herData.newVersion}
        </span>
        <div className="flex-1 h-[1px] bg-gradient-to-l from-primary/40 to-transparent"></div>
      </div>

      {/* PRIMARY METRICS GRID */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Integrity', val: herData.verificationVerdict, color: getVerdictColor(herData.verificationVerdict), Icon: ShieldCheck },
          { label: 'Neural Confidence', val: `${(herData.confidenceScore * 100).toFixed(1)}%`, color: 'text-primary-light', Icon: BrainCircuit },
          { label: 'Evolution Depth', val: `v${herData.newVersion}`, color: 'text-secondary-light', Icon: Layers },
          { label: 'Mutation Cycles', val: herData.causalHistory?.length || 0, color: 'text-green-400', Icon: Zap },
        ].map((item, i) => (
          <div key={i} className="bg-neutral-900/60 border border-neutral-800 p-4 rounded-sm relative overflow-hidden group hover:border-primary/50 transition-all cursor-default">
            <div className="flex items-center justify-between mb-2">
               <item.Icon className={`h-4 w-4 ${item.color}`} />
               <span className="text-[8px] font-mono uppercase text-neutral-500 tracking-widest">{item.label}</span>
            </div>
            <div className={`text-xl font-orbitron font-black ${item.color} tracking-tighter drop-shadow-[0_0_8px_rgba(0,0,0,1)]`}>
              {item.val}
            </div>
            <div className="absolute -bottom-1 -right-1 opacity-5 group-hover:opacity-10 transition-opacity">
              <item.Icon className="h-12 w-12" />
            </div>
          </div>
        ))}
      </div>

      {/* LIVE CODE INJECTION VIEW (The Money Shot) */}
      <div className="relative">
        <div className="absolute -top-3 left-6 px-2 bg-neutral-900 border border-neutral-800 text-[9px] font-mono text-primary z-10 font-bold tracking-widest uppercase shadow-sm flex items-center gap-2">
          <Code2 className="h-3 w-3" /> Live Mutation Diff
          <button 
            onClick={() => setShowDiff(!showDiff)} 
            className="ml-4 px-2 py-0.5 bg-primary/10 hover:bg-primary/20 border border-primary/30 rounded text-primary text-[8px] transition-all"
          >
            {showDiff ? 'VIEW_RAW' : 'VIEW_DIFF'}
          </button>
        </div>
        
        <Card className="bg-black/95 pt-8 shadow-inner border-primary/20 overflow-hidden" Icon={Terminal}>
          {!showDiff ? (
            <TextArea
              value={herData.newFullPrompt.replace(/{{nextPlannedMutationText}}/g, herData.nextPlannedMutationText)}
              readOnly
              className="w-full h-[500px] bg-transparent border-none text-primary-light/80 font-mono text-[11px] leading-relaxed resize-none focus:ring-0 selection:bg-primary/30 scrollbar-hide"
            />
          ) : (
            <div className="grid grid-cols-2 gap-4 h-[500px] overflow-hidden">
              <div className="flex flex-col border-r border-neutral-800 pr-2">
                <span className="text-[8px] font-mono text-neutral-600 mb-2 uppercase tracking-widest">PREVIOUS_ARCHITECTURE</span>
                <div className="flex-1 overflow-auto bg-red-950/5 p-2 rounded text-[10px] font-mono text-neutral-500 line-through opacity-60">
                  {previousPrompt}
                </div>
              </div>
              <div className="flex flex-col pl-2">
                <span className="text-[8px] font-mono text-primary/60 mb-2 uppercase tracking-widest flex items-center gap-2">
                  <ArrowRight className="h-2 w-2" /> MUTATED_ARCHITECTURE
                </span>
                <div className="flex-1 overflow-auto bg-green-950/5 p-2 rounded text-[10px] font-mono text-green-400">
                  {herData.newFullPrompt}
                </div>
              </div>
            </div>
          )}
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 space-y-6">
           <Card title="Structural Delta Log" Icon={GitBranch}>
            <div className="space-y-4">
               <div className="p-4 bg-black/60 border border-neutral-800 rounded font-mono text-[11px] text-neutral-400 max-h-48 overflow-auto leading-relaxed">
                  <div className="text-primary mb-2 border-b border-neutral-800 pb-1 text-[9px] uppercase font-bold tracking-[0.2em] flex items-center justify-between">
                     <span>Inbound Changelog</span>
                     <Activity className="h-3 w-3 opacity-50" />
                  </div>
                  {herData.changelogEntry}
               </div>
               <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <span className="text-[9px] font-black text-neutral-500 uppercase tracking-widest border-b border-neutral-800 pb-1 block">Threat Analysis</span>
                    <div className="space-y-1">
                      {herData.reflectionOutput.identifiedImprovements.map((imp, i) => (
                        <div key={i} className="text-[9px] font-mono text-red-400 flex gap-2 items-start">
                          <span className="shrink-0 text-red-500/50">#</span> {imp}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <span className="text-[9px] font-black text-neutral-500 uppercase tracking-widest border-b border-neutral-800 pb-1 block">Logic Vectors</span>
                    <div className="text-[10px] font-mono text-green-400 space-y-1">
                      <div className="flex justify-between"><span>RECURSION:</span> <span>{herData.causalHistory.length}x</span></div>
                      <div className="flex justify-between"><span>BIAS_MAP:</span> <span>{(herData.confidenceScore * 0.12).toFixed(4)}</span></div>
                      <div className="flex justify-between text-primary"><span>ENTROPY:</span> <span className="animate-pulse">STABLE</span></div>
                    </div>
                  </div>
               </div>
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Core Principles" Icon={Cpu}>
            <div className="space-y-3 max-h-48 overflow-y-auto pr-2 scrollbar-hide">
              {herData.extractedPrinciples.map((p, idx) => (
                <div key={idx} className="p-2 bg-neutral-800/40 border-l-2 border-primary rounded-r text-[10px] font-mono text-neutral-300 leading-relaxed group hover:bg-primary/10 transition-colors">
                  <span className="text-primary mr-1 font-bold">L_{idx}:</span> {p}
                </div>
              ))}
            </div>
          </Card>

          <Card title="Active Directives" Icon={Target}>
            <div className="space-y-3 max-h-48 overflow-y-auto pr-2 scrollbar-hide">
              {herData.formulatedDirectives.map((d, idx) => (
                <div key={idx} className="p-2 bg-neutral-800/40 border-l-2 border-secondary rounded-r text-[10px] font-mono text-neutral-300 leading-relaxed group hover:bg-secondary/10 transition-colors">
                  <span className="text-secondary mr-1 font-bold">E_{idx}:</span> {d}
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      <Card title="Master Causality Ledger" Icon={Database}>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[11px] font-mono text-neutral-400 border-collapse">
            <thead className="text-[8px] uppercase bg-neutral-800/20 text-neutral-500 tracking-[0.2em]">
              <tr>
                <th className="px-4 py-3 border-b border-neutral-800">SEQ_ID</th>
                <th className="px-4 py-3 border-b border-neutral-800">TS_REF</th>
                <th className="px-4 py-3 border-b border-neutral-800">DELTA_ACTION</th>
                <th className="px-4 py-3 border-b border-neutral-800">INTEGRITY</th>
                <th className="px-4 py-3 border-b border-neutral-800 text-right">CONF_LVL</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/30">
              {herData.causalHistory?.slice().reverse().map((entry) => (
                <tr key={entry.id} className="hover:bg-primary/5 transition-colors group">
                  <td className="px-4 py-3 text-primary font-bold">#{entry.id}</td>
                  <td className="px-4 py-3 text-neutral-700 whitespace-nowrap">{new Date(entry.timestamp).toLocaleTimeString()}</td>
                  <td className="px-4 py-3 truncate max-w-[400px] group-hover:text-primary-light transition-colors">
                    {entry.action}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold ${entry.confidence > 0.8 ? 'bg-green-500/10 text-green-500' : 'bg-yellow-500/10 text-yellow-500'}`}>
                      {entry.confidence > 0.8 ? 'SOLID' : 'DEVIATED'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-black text-secondary">{Math.round(entry.confidence * 100)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default HerDisplayPanel;
