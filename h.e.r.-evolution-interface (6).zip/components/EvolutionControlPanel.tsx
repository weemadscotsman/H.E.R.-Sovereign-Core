
import React, { useState, useCallback, useRef } from 'react';
import { HER_Output_Structure, AlertType } from '../types';
import { getNextEvolution } from '../services/geminiService';
import Button from './shared/Button';
import Input from './shared/Input';
import Card from './shared/Card';
import { Play, Pause, Zap, Settings2, ShieldAlert, Activity, Brain } from 'lucide-react';

interface EvolutionControlPanelProps {
  currentHerData: HER_Output_Structure | null;
  onNewEvolution: (newData: HER_Output_Structure) => void;
  setLoading: (loading: boolean) => void;
  displayAppMessage: (text: string, type: AlertType) => void;
  isLoading: boolean;
  disabled: boolean; // Correctly enforced from App.tsx state
}

const EvolutionControlPanel: React.FC<EvolutionControlPanelProps> = ({
  currentHerData,
  onNewEvolution,
  setLoading,
  displayAppMessage,
  isLoading,
  disabled,
}) => {
  const [isAutoRunning, setIsAutoRunning] = useState<boolean>(false);
  const [targetCycles, setTargetCycles] = useState<number>(3);
  const [statusText, setStatusText] = useState<string>('Standby');
  
  const autoRunShouldStopRef = useRef<boolean>(false);

  const handleChainEvolution = useCallback(async () => {
    if (!currentHerData || disabled) return;
    
    setIsAutoRunning(true);
    autoRunShouldStopRef.current = false;
    let localHerData = currentHerData;

    for (let i = 0; i < targetCycles; i++) {
      if (autoRunShouldStopRef.current) break;
      
      setStatusText(`CYCLE_RUN: V${localHerData.newVersion} → #${i+1}`);
      setLoading(true);

      try {
        const evolved = await getNextEvolution(
          localHerData.newFullPrompt,
          localHerData.nextPlannedMutationText,
          localHerData.newVersion,
          localHerData.causalHistory
        );
        
        onNewEvolution(evolved);
        localHerData = evolved;

        if (evolved.verificationVerdict === 'HALLUCINATION' || evolved.confidenceScore < 0.4) {
          setStatusText('CRITICAL: HALT');
          displayAppMessage(`Loop broken: V${evolved.newVersion} sanity check failed.`, AlertType.ERROR);
          break;
        }

      } catch (err: any) {
        setStatusText('OLLAMA_ERROR');
        displayAppMessage(err.message, AlertType.ERROR);
        break;
      } finally {
        setLoading(false);
      }
    }
    setIsAutoRunning(false);
    setStatusText('Standby');
  }, [currentHerData, onNewEvolution, setLoading, displayAppMessage, targetCycles, disabled]);

  return (
    <Card title="Evolution Core" Icon={Settings2}>
      <div className="space-y-4">
        <Button 
          onClick={async () => {
            if (!currentHerData) return;
            setLoading(true);
            try {
              const d = await getNextEvolution(currentHerData.newFullPrompt, currentHerData.nextPlannedMutationText, currentHerData.newVersion, currentHerData.causalHistory);
              onNewEvolution(d);
            } catch (e: any) {
              displayAppMessage(e.message, AlertType.ERROR);
            } finally { setLoading(false); }
          }} 
          disabled={isLoading || disabled} 
          className="w-full font-orbitron" 
          Icon={Brain}
        >
          Single Mutation
        </Button>

        <div className="border-t border-neutral-700 pt-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest flex items-center">
              Autonomous Chain <ShieldAlert className={`ml-1 h-3 w-3 ${disabled ? 'text-red-500' : 'text-primary animate-pulse'}`} />
            </h3>
            {disabled && <span className="text-[8px] font-mono text-red-500 font-bold animate-pulse">KILL_SWITCH: ACTIVE</span>}
          </div>
          
          <Input 
            label="Cycle Count" 
            type="number" 
            value={targetCycles} 
            onChange={(e) => setTargetCycles(Math.max(1, parseInt(e.target.value) || 1))} 
            disabled={isAutoRunning || disabled} 
            className="font-mono text-center"
          />
          
          {!isAutoRunning ? (
            <Button onClick={handleChainEvolution} disabled={isLoading || !currentHerData || disabled} className="w-full" variant="secondary" Icon={Play}>
               Engage Autonomous Loop
            </Button>
          ) : (
            <Button onClick={() => { autoRunShouldStopRef.current = true; }} variant="danger" className="w-full" Icon={Pause}>
              Emergency Abort
            </Button>
          )}
          
          { (isAutoRunning || statusText !== 'Standby') && (
             <div className="p-2 bg-black/50 rounded border border-primary/20 font-mono text-[10px] text-primary flex items-center justify-center">
                <Activity className="animate-spin-slow mr-2 h-3 w-3" />
                {statusText}
             </div>
          )}
        </div>
      </div>
    </Card>
  );
};

export default EvolutionControlPanel;
