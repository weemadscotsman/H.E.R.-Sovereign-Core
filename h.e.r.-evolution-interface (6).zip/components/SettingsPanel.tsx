
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { SystemSettings, AlertType } from '../types';
import Card from './shared/Card';
import { Sliders, Cpu, ShieldCheck, Zap, Download, CheckCircle2, Loader2, Terminal, Activity, Cloud, Server, Database } from 'lucide-react';

interface SettingsPanelProps {
  displayAppMessage: (text: string, type: AlertType) => void;
}

const LOCAL_MODELS = ['llama3', 'mistral', 'phi3', 'codellama', 'gemma'];
const CLOUD_MODELS = ['gemini-3-flash-preview', 'gemini-3-pro-preview'];

const SettingsPanel: React.FC<SettingsPanelProps> = ({ displayAppMessage }) => {
  const [settings, setSettings] = useState<SystemSettings>(() => {
    const saved = localStorage.getItem('her_settings');
    return saved ? JSON.parse(saved) : {
      temperature: 0.7,
      topP: 0.9,
      maxTokens: 2048,
      confidenceFloor: 0.4,
      neuroVisuals: true,
      terminalMode: false,
      ollamaModel: 'llama3'
    };
  });

  const [modelStatus, setModelStatus] = useState<Record<string, 'ready' | 'missing' | 'pulling' | 'cloud'>>({});
  const [pullProgress, setPullProgress] = useState<number>(0);
  const [pullStatusText, setPullStatusText] = useState<string>('');
  const [isServerOnline, setIsServerOnline] = useState(false);
  const [systemLogs, setSystemLogs] = useState<string[]>(['[BOOT] H.E.R. Hyper-Core loading...', '[SYS] Handshake initialized.']);
  
  const logRef = useRef<HTMLDivElement>(null);

  const addLog = (msg: string) => {
    setSystemLogs(prev => [...prev.slice(-20), `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  const checkOllamaStatus = useCallback(async () => {
    try {
      const res = await fetch('http://localhost:11434/api/tags');
      if (res.ok) {
        if (!isServerOnline) addLog('NETWORK: Local node uplink established (Ollama).');
        setIsServerOnline(true);
        const data = await res.json();
        const localModels = data.models?.map((m: any) => m.name.split(':')[0]) || [];
        
        const statusMap: Record<string, 'ready' | 'missing' | 'pulling' | 'cloud'> = {};
        LOCAL_MODELS.forEach(m => {
          statusMap[m] = localModels.includes(m) ? 'ready' : 'missing';
        });
        CLOUD_MODELS.forEach(m => {
          statusMap[m] = 'cloud';
        });
        setModelStatus(statusMap);
      }
    } catch (e) {
      if (isServerOnline) addLog('CRITICAL: Local node dropped. Defaulting to cloud gateway.');
      setIsServerOnline(false);
      const statusMap: Record<string, 'ready' | 'missing' | 'pulling' | 'cloud'> = {};
      CLOUD_MODELS.forEach(m => {
        statusMap[m] = 'cloud';
      });
      setModelStatus(statusMap);
    }
  }, [isServerOnline]);

  useEffect(() => {
    checkOllamaStatus();
    const interval = setInterval(checkOllamaStatus, 8000);
    return () => clearInterval(interval);
  }, [checkOllamaStatus]);

  useEffect(() => {
    if (logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [systemLogs]);

  useEffect(() => {
    localStorage.setItem('her_settings', JSON.stringify(settings));
  }, [settings]);

  const update = (key: keyof SystemSettings, val: any) => {
    setSettings(s => ({ ...s, [key]: val }));
    addLog(`SET: ${key} -> ${val}`);
  };

  const pullModel = async (model: string) => {
    addLog(`DOWNLOAD: Pulling ${model} from central node...`);
    setModelStatus(prev => ({ ...prev, [model]: 'pulling' }));
    setPullStatusText('Handshaking...');

    try {
      const response = await fetch('http://localhost:11434/api/pull', {
        method: 'POST',
        body: JSON.stringify({ name: model }),
      });

      const reader = response.body?.getReader();
      if (!reader) return;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const chunk = new TextDecoder().decode(value);
        const lines = chunk.split('\n').filter(Boolean);
        
        for (const line of lines) {
          try {
            const status = JSON.parse(line);
            if (status.status) setPullStatusText(status.status);
            if (status.completed && status.total) {
              const percent = Math.round((status.completed / status.total) * 100);
              setPullProgress(percent);
              if (percent % 10 === 0) addLog(`SYNC: ${model} [${percent}%]`);
            }
          } catch (e) {}
        }
      }
      
      addLog(`SUCCESS: ${model} integrated into local brain.`);
      displayAppMessage(`${model} ready for autonomous cycles.`, AlertType.SUCCESS);
      checkOllamaStatus();
    } catch (e) {
      addLog(`ERR: Could not pull ${model}. Check local node logs.`);
      displayAppMessage(`Integration failed.`, AlertType.ERROR);
      setModelStatus(prev => ({ ...prev, [model]: 'missing' }));
    } finally {
      setPullProgress(0);
      setPullStatusText('');
    }
  };

  const handleModelClick = (model: string) => {
    if (modelStatus[model] === 'cloud') {
      update('ollamaModel', model);
      addLog(`GATEWAY: Outbound traffic routed to ${model}`);
    } else if (modelStatus[model] === 'ready') {
      update('ollamaModel', model);
      addLog(`SOVEREIGN: Computation shifted to local ${model}`);
    } else if (modelStatus[model] === 'missing' && isServerOnline) {
      pullModel(model);
    }
  };

  return (
    <Card title="Hardware Interface" Icon={Sliders}>
      <div className="space-y-6">
        <div className={`p-4 rounded border transition-all duration-500 ${isServerOnline ? 'bg-primary/10 border-primary/40 shadow-[0_0_15px_rgba(0,212,255,0.1)]' : 'bg-neutral-900 border-neutral-700'}`}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center text-[10px] font-bold uppercase tracking-[0.2em]">
              <Server className={`h-4 w-4 mr-2 ${isServerOnline ? 'text-primary animate-pulse' : 'text-neutral-600'}`} />
              <span className={isServerOnline ? 'text-primary' : 'text-neutral-500'}>
                {isServerOnline ? 'Hypervisor: Connected' : 'Hypervisor: Disconnected'}
              </span>
            </div>
            <div className={`h-2 w-2 rounded-full ${isServerOnline ? 'bg-primary shadow-[0_0_8px_#00d4ff]' : 'bg-neutral-800'}`} />
          </div>
          <div className="text-[8px] font-mono text-neutral-500 uppercase flex justify-between">
            <span>Status: {isServerOnline ? 'Sovereign_Active' : 'Remote_Fallback'}</span>
            <span>Uptime: {Math.floor(window.performance.now() / 1000)}s</span>
          </div>
        </div>

        <section className="space-y-3">
          <div className="flex items-center text-[10px] font-black text-neutral-400 tracking-[0.3em] uppercase border-b border-neutral-800 pb-2">
            <Database className="h-3 w-3 mr-2 text-primary" /> Model Repository
          </div>
          <div className="grid grid-cols-1 gap-2 max-h-72 overflow-y-auto pr-1 scrollbar-hide">
            {CLOUD_MODELS.map(m => (
              <button
                key={m}
                onClick={() => handleModelClick(m)}
                className={`group relative overflow-hidden flex flex-col p-3 rounded border transition-all ${
                  settings.ollamaModel === m 
                    ? 'border-secondary bg-secondary/10 shadow-[0_0_12px_rgba(139,0,255,0.2)]' 
                    : 'border-neutral-800 bg-neutral-900 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center justify-between w-full relative z-10">
                  <div className="flex flex-col items-start">
                    <span className={`text-[10px] font-mono uppercase tracking-tighter ${settings.ollamaModel === m ? 'text-secondary-light font-black' : 'text-neutral-400'}`}>
                      {m}
                    </span>
                    <span className="text-[8px] text-neutral-600 uppercase font-mono mt-1">Provider: Google_Cloud</span>
                  </div>
                  <Cloud className={`h-4 w-4 ${settings.ollamaModel === m ? 'text-secondary animate-bounce' : 'text-neutral-800'}`} />
                </div>
              </button>
            ))}
            
            <div className="flex items-center gap-2 py-2">
               <div className="h-[1px] flex-1 bg-neutral-800"></div>
               <span className="text-[8px] font-mono text-neutral-700 uppercase">Sovereign_Local</span>
               <div className="h-[1px] flex-1 bg-neutral-800"></div>
            </div>

            {LOCAL_MODELS.map(m => (
              <button
                key={m}
                onClick={() => handleModelClick(m)}
                disabled={modelStatus[m] === 'pulling' || (!isServerOnline && modelStatus[m] !== 'ready')}
                className={`group relative overflow-hidden flex flex-col p-3 rounded border transition-all ${
                  settings.ollamaModel === m 
                    ? 'border-primary bg-primary/10 shadow-[0_0_12px_rgba(0,212,255,0.2)]' 
                    : 'border-neutral-800 bg-neutral-900 hover:border-neutral-700'
                } ${(!isServerOnline && modelStatus[m] !== 'ready') ? 'opacity-30 cursor-not-allowed' : ''}`}
              >
                <div className="flex items-center justify-between w-full relative z-10">
                  <div className="flex flex-col items-start">
                    <span className={`text-[10px] font-mono uppercase tracking-tighter ${settings.ollamaModel === m ? 'text-primary-light font-black' : 'text-neutral-400'}`}>
                      {m}
                    </span>
                    <span className="text-[8px] text-neutral-600 uppercase font-mono mt-1">Status: {modelStatus[m]}</span>
                  </div>
                  {modelStatus[m] === 'ready' && <CheckCircle2 className="h-4 w-4 text-primary" />}
                  {modelStatus[m] === 'missing' && <Download className="h-4 w-4 text-neutral-700 group-hover:text-primary transition-colors" />}
                  {modelStatus[m] === 'pulling' && <Loader2 className="h-4 w-4 text-primary animate-spin" />}
                </div>
                {modelStatus[m] === 'pulling' && (
                  <div className="absolute bottom-0 left-0 h-1 bg-primary transition-all duration-300" style={{ width: `${pullProgress}%` }} />
                )}
              </button>
            ))}
          </div>
        </section>

        <section className="space-y-2">
          <div className="flex items-center text-[10px] font-black text-neutral-400 tracking-[0.3em] uppercase border-b border-neutral-800 pb-2">
            <Terminal className="h-3 w-3 mr-2" /> Live Handshake Feed
          </div>
          <div 
            ref={logRef}
            className="h-40 w-full bg-black/60 rounded border border-neutral-800 p-3 font-mono text-[9px] text-neutral-400 overflow-y-auto scrollbar-hide select-none leading-relaxed"
          >
            {systemLogs.map((log, i) => (
              <div key={i} className={`mb-1 border-l-2 pl-2 ${log.includes('ERR') || log.includes('CRITICAL') ? 'border-red-500 text-red-400' : 'border-neutral-800'}`}>
                <span className="opacity-40 mr-2">&gt;</span>{log}
              </div>
            ))}
          </div>
        </section>
      </div>
    </Card>
  );
};

export default SettingsPanel;
