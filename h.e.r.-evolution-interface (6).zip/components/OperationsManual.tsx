
import React from 'react';
import Card from './shared/Card';
import { BookOpen, Shield, Zap, Radio, Github, Cpu, Terminal, Info, X, Lightbulb, AlertTriangle } from 'lucide-react';

interface OperationsManualProps {
  isOpen: boolean;
  onClose: () => void;
}

const OperationsManual: React.FC<OperationsManualProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[1000] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 md:p-8 animate-in fade-in zoom-in duration-300">
      <div className="w-full max-w-5xl h-full max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-lg shadow-[0_0_50px_rgba(0,0,0,1)] flex flex-col overflow-hidden relative">
        
        {/* Header */}
        <div className="p-6 border-b border-neutral-800 flex items-center justify-between bg-black/40">
          <div className="flex items-center gap-3">
            <BookOpen className="h-6 w-6 text-primary shadow-[0_0_10px_#00d4ff]" />
            <h2 className="font-orbitron font-black text-xl tracking-[0.3em] uppercase italic text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
              Sovereign_Ops_Manual // V1.0
            </h2>
          </div>
          <button onClick={onClose} className="text-neutral-500 hover:text-white transition-colors p-2 bg-neutral-800 rounded-full">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 md:p-10 space-y-12 font-sans selection:bg-primary/30">
          
          {/* Section: Overview */}
          <section className="space-y-4">
            <h3 className="text-primary-light font-orbitron text-sm font-black tracking-widest uppercase flex items-center gap-2">
              <Cpu className="h-4 w-4" /> 01. The Cognitive Engine
            </h3>
            <p className="text-neutral-400 text-sm leading-relaxed font-mono">
              H.E.R. (Hyper-Evolutionary Rewriter) is not a static chatbot. It is a recursive logic engine designed to mutate its own instruction set (DNA). 
              Unlike standard AI interfaces, this system treats its own prompt as <span className="text-secondary-light">variable code</span>. Every "Evolution Cycle" results in a new version of the system, capable of higher reasoning and tool abstraction.
            </p>
          </section>

          {/* Section: VTL */}
          <section className="space-y-4">
            <h3 className="text-primary-light font-orbitron text-sm font-black tracking-widest uppercase flex items-center gap-2">
              <Terminal className="h-4 w-4" /> 02. Visual Telemetry (VTL)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-black/40 p-4 border border-neutral-800 rounded">
                <h4 className="text-[10px] font-bold text-neutral-300 uppercase mb-2">The Event Spine</h4>
                <p className="text-[11px] text-neutral-500 font-mono">Located at the bottom-right. It logs every state transition. If the model thinks, it logs. If the sensor triggers, it logs. No silent state changes allowed.</p>
              </div>
              <div className="bg-black/40 p-4 border border-neutral-800 rounded">
                <h4 className="text-[10px] font-bold text-neutral-300 uppercase mb-2">System Pulse</h4>
                <p className="text-[11px] text-neutral-500 font-mono">The heartbeat monitor. Real-time indicators of Neural Engine status, Persistence connection, and Hardware arming states.</p>
              </div>
            </div>
          </section>

          {/* Section: Tutorial */}
          <section className="space-y-4 bg-primary/5 p-6 border border-primary/20 rounded-lg">
            <h3 className="text-primary-light font-orbitron text-sm font-black tracking-widest uppercase flex items-center gap-2">
              <Lightbulb className="h-4 w-4" /> 03. Tutorial: First Evolution
            </h3>
            <ol className="space-y-4 text-sm font-mono text-neutral-300">
              <li className="flex gap-4">
                <span className="text-primary font-black">STEP_01</span>
                <span>Arm the <span className="text-white">SYSTEM_ARM</span> toggle in the Sensory Telemetry panel. This readies the hardware interrupts.</span>
              </li>
              <li className="flex gap-4">
                <span className="text-primary font-black">STEP_02</span>
                <span>Enable <span className="text-white">Optical_Feed</span> or <span className="text-white">Audio_Feed</span>. The system will now begin sampling your environment for motion or specific vocal intents.</span>
              </li>
              <li className="flex gap-4">
                <span className="text-primary font-black">STEP_03</span>
                <span>Trigger a Mutation. You can do this manually via the "Single Mutation" button, or speak the words <span className="italic text-secondary-light">"Initiate Evolution"</span> into an active mic.</span>
              </li>
              <li className="flex gap-4">
                <span className="text-primary font-black">STEP_04</span>
                <span>Observe the <span className="text-white">Live Mutation Diff</span>. Watch as the system injects new logic into its own core architecture.</span>
              </li>
            </ol>
          </section>

          {/* Section: Safety */}
          <section className="space-y-4">
            <h3 className="text-red-500 font-orbitron text-sm font-black tracking-widest uppercase flex items-center gap-2">
              <Shield className="h-4 w-4" /> 04. Sovereign Isolation (Kill Switch)
            </h3>
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <div className="p-4 bg-red-950/10 border border-red-900/40 rounded flex-1">
                <div className="flex items-center gap-2 text-red-400 mb-2">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="text-[10px] font-black uppercase">Absolute Protocol</span>
                </div>
                <p className="text-[11px] text-neutral-500 font-mono leading-relaxed">
                  The Sovereign Kill Switch is a hard-coded gate. When active, it:
                  <br/>1. Terminates all MediaStreams (Cam/Mic).
                  <br/>2. Discards Auth Broker tokens.
                  <br/>3. Rejects all outbound Neural Core API requests.
                  <br/>4. Freezes the VTL Spine.
                </p>
              </div>
              <div className="p-4 bg-black/20 border border-neutral-800 rounded flex-1">
                <h4 className="text-[10px] font-bold text-neutral-300 uppercase mb-2">Persistence Flow</h4>
                <p className="text-[11px] text-neutral-500 font-mono">
                  GitHub integration acts as an external DNA bank. Each mutation can be synced to a version-controlled repository to maintain a permanent record of the system's lineage.
                </p>
              </div>
            </div>
          </section>

        </div>

        {/* Footer */}
        <div className="p-4 bg-black border-t border-neutral-800 flex justify-center">
          <p className="text-[9px] font-mono text-neutral-600 uppercase tracking-[0.5em]">
            // END_OF_FILE: OPS_MANUAL_H.E.R. //
          </p>
        </div>
      </div>
    </div>
  );
};

export default OperationsManual;
