
import React, { useState, useEffect, useRef } from 'react';
import { vtl, TelemetryEvent } from '../services/telemetry';
import { Activity, Cpu, Database, ChevronUp, ChevronDown, Maximize2, Minimize2 } from 'lucide-react';

export const VisualTelemetryLayer: React.FC<{ isKillSwitchActive: boolean }> = ({ isKillSwitchActive }) => {
  const [events, setEvents] = useState<TelemetryEvent[]>(vtl.getHistory());
  const [isExpanded, setIsExpanded] = useState(false);
  const [panelHeight, setPanelHeight] = useState(384); // Default 96rem/384px
  const scrollRef = useRef<HTMLDivElement>(null);
  const isResizing = useRef(false);

  useEffect(() => {
    const unsubscribe = vtl.subscribe((event) => {
      setEvents(prev => [...prev.slice(-49), event]);
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (scrollRef.current && isExpanded) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [events, isExpanded]);

  const startResizing = (e: React.MouseEvent | React.TouchEvent) => {
    isResizing.current = true;
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', stopResizing);
    document.addEventListener('touchmove', handleTouchMove);
    document.addEventListener('touchend', stopResizing);
  };

  const stopResizing = () => {
    isResizing.current = false;
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', stopResizing);
    document.removeEventListener('touchmove', handleTouchMove);
    document.removeEventListener('touchend', stopResizing);
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isResizing.current) return;
    const newHeight = window.innerHeight - e.clientY - 60;
    setPanelHeight(Math.max(150, Math.min(newHeight, window.innerHeight * 0.8)));
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (!isResizing.current) return;
    const newHeight = window.innerHeight - e.touches[0].clientY - 60;
    setPanelHeight(Math.max(150, Math.min(newHeight, window.innerHeight * 0.8)));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'SUCCESS': return 'text-primary';
      case 'ERROR': return 'text-red-500 font-bold';
      case 'BLOCKED': return 'text-orange-500';
      default: return 'text-neutral-500';
    }
  };

  return (
    <div className={`fixed bottom-4 right-4 z-[100] transition-all duration-300 ease-in-out flex flex-col pointer-events-none
      ${isExpanded ? 'w-[90vw] md:w-96' : 'w-64 md:w-72'}`}>
      
      {/* RESIZE HANDLE */}
      {isExpanded && (
        <div 
          onMouseDown={startResizing}
          onTouchStart={startResizing}
          className="h-2 w-full cursor-ns-resize hover:bg-primary/20 transition-colors flex items-center justify-center pointer-events-auto"
        >
          <div className="w-8 h-0.5 bg-neutral-700 rounded-full"></div>
        </div>
      )}

      {/* GLOBAL SYSTEM PULSE (HEADER) */}
      <div className={`bg-black/95 border border-neutral-800 p-3 rounded-t-md flex items-center justify-between font-mono text-[10px] uppercase tracking-tighter pointer-events-auto
        ${isKillSwitchActive ? 'border-red-900/50 shadow-[0_0_15px_rgba(255,0,0,0.1)]' : 'border-primary/30 shadow-[0_0_15px_rgba(0,212,255,0.05)]'}`}>
        <div className="flex items-center gap-2">
          <Activity className={`h-3 w-3 ${isKillSwitchActive ? 'text-red-500' : 'text-primary animate-pulse'}`} />
          <span className={isKillSwitchActive ? 'text-red-500 font-black' : 'text-neutral-300 font-medium'}>
            {isKillSwitchActive ? 'CORE_FROZEN' : 'SYSTEM_PULSE'}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex gap-2">
            <Database className={`h-3 w-3 ${isKillSwitchActive ? 'text-neutral-800' : 'text-primary/60'}`} />
            <Cpu className={`h-3 w-3 ${isKillSwitchActive ? 'text-neutral-800' : 'text-secondary/60'}`} />
          </div>
          <button 
            onClick={() => setIsExpanded(!isExpanded)} 
            className="flex items-center gap-1 hover:text-white transition-colors bg-neutral-800/50 px-2 py-0.5 rounded border border-neutral-700"
          >
            {isExpanded ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
            <span className="text-[8px]">{isExpanded ? 'HIDE' : 'LOGS'}</span>
          </button>
        </div>
      </div>

      {/* EVENT SPINE (BODY) */}
      <div 
        ref={scrollRef}
        style={{ height: isExpanded ? `${panelHeight}px` : '0px' }}
        className={`bg-neutral-900/98 border-x border-b border-neutral-800 overflow-y-auto scrollbar-hide transition-all duration-300 pointer-events-auto
          ${isExpanded ? 'opacity-100 p-2' : 'opacity-0'}`}
      >
        <div className="space-y-1.5">
          {events.length === 0 && (
            <div className="text-center py-4 text-[9px] text-neutral-700 italic font-mono">
              Awaiting neural signals...
            </div>
          )}
          {events.map((ev, i) => (
            <div key={i} className="flex flex-col gap-0.5 font-mono text-[9px] border-b border-neutral-800/40 pb-1.5 last:border-0 group animate-in slide-in-from-right-2 duration-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="text-neutral-600 tabular-nums">{ev.timestamp.split('T')[1].split('.')[0]}</span>
                  <span className="text-neutral-500 font-black text-[8px] bg-neutral-800/50 px-1 rounded">
                    {ev.subsystem}
                  </span>
                </div>
                <span className={`text-[8px] px-1 rounded-sm border ${
                  ev.status === 'SUCCESS' ? 'border-primary/20 text-primary' : 
                  ev.status === 'ERROR' ? 'border-red-500/20 text-red-500' : 
                  'border-neutral-700 text-neutral-500'
                }`}>
                  {ev.status}
                </span>
              </div>
              <div className="flex items-start gap-2">
                <span className={`flex-1 font-medium ${getStatusColor(ev.status)}`}>{ev.action}</span>
              </div>
              <div className="hidden group-hover:block overflow-x-auto bg-black/40 p-1.5 mt-1 rounded text-[7px] text-neutral-500 break-all whitespace-pre-wrap">
                {JSON.stringify(ev.payload, null, 2)}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* KILL SWITCH ALERT OVERLAY */}
      {isKillSwitchActive && (
        <div className="absolute inset-0 bg-red-950/10 pointer-events-none animate-pulse border-2 border-red-600/30 rounded-md"></div>
      )}
    </div>
  );
};
