
export interface SystemSettings {
  temperature: number;
  topP: number;
  maxTokens: number;
  confidenceFloor: number;
  neuroVisuals: boolean;
  terminalMode: boolean;
  ollamaModel: string;
}

export interface ReflectionOutput {
  evaluationSummary: string;
  identifiedImprovements: string[];
  rationaleForNextMutation: string;
}

export interface CausalEntry {
  id: string;
  problem: string;
  action: string;
  result: string;
  confidence: number;
  timestamp: number;
}

export interface HER_Output_Structure {
  newVersion: string;
  timestamp: string;
  changelogEntry: string;
  nextPlannedMutationText: string;
  extractedPrinciples: string[];
  formulatedDirectives: string[];
  reflectionOutput: ReflectionOutput;
  newFullPrompt: string;
  confidenceScore: number; 
  verificationVerdict: 'VALID' | 'PARTIAL' | 'HALLUCINATION';
  causalHistory: CausalEntry[];
}

export interface GitHubRepoConfig {
  pat: string;
  owner: string;
  repo: string;
  branch: string;
  filePath: string;
}

export enum AlertType {
  SUCCESS = 'success',
  ERROR = 'error',
  WARNING = 'warning',
  INFO = 'info'
}
